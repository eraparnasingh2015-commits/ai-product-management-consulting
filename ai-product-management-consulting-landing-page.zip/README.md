# AI Product Management Consulting

A premium, static landing page for a fractional product management / AI product strategy consultancy.

## Deploy
This site is plain HTML + CSS and works on GitHub Pages, Netlify, Vercel static hosting, or any standard web host.

## Before launch
1. Replace `YOUR_EMAIL@example.com` in `index.html` with the real contact email.
2. Replace the illustrative sample work with real case studies as they become available.
3. Add a real scheduling link later (Calendly/Cal.com) once set up.

## Positioning
Help early-stage SaaS and AI startups turn product ambiguity into validated scope, build-ready PRDs, MVP plans and ongoing product execution.
